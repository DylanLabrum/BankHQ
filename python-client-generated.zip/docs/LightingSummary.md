# LightingSummary

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**zones** | [**list[LightingZone]**](LightingZone.md) |  | [optional] 
**zone_status** | [**list[LightingZoneStatus]**](LightingZoneStatus.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

