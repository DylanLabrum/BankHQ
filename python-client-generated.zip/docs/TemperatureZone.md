# TemperatureZone

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | the unique identifier for the zone | 
**name** | **str** |  | 
**input_position** | **int** |  | [optional] 
**output_position** | **int** |  | [optional] 
**zone** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

